# Multiplicador Online

Juego de multiplicaciones multijugador en tiempo real.

## 🚀 Cómo desplegar en Render

1. Sube esta carpeta a un repositorio de GitHub.
2. Ve a [https://render.com](https://render.com)
3. Crea un nuevo servicio "Web Service"
4. Conecta tu repositorio
5. Usa estos ajustes:

- **Build command:** `npm install`
- **Start command:** `npm start`
- **Environment:** Node
- **Region:** EU o US según tu ubicación

Render te dará una URL pública para jugar desde cualquier lugar 🌍